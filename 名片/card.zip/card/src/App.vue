<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
    name: 'App',
}
</script>

<style>
  @import "./assets/css/global.less";
  @import "./assets/css/style.css";
  @import "./assets/font/iconfont.css";
</style>
